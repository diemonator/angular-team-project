'use strict';

angular.module('myApp.view4', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view4', {
    templateUrl: 'view4/view4.html',
    controller: 'View4Ctrl'
  });
}])


 .factory('View4Factory',['myFactory1','myFactory2','myFactory3', function dashboard (myFactory1,myFactory2,myFactory3)
    {
        var j = -1;
        var t = -1;
        var h = -1;

        var returnedArray = {};
        returnedArray.data = [];
        function newProp () {
            j++;
            return myFactory1.data[j].department;
        }
        function newPropEmp () {
            t++;
            return myFactory2.data[t].employee;
        }
        function newPropTask () {
            h++;
            return myFactory3.data[h].task;
        }
        for (var i=0;i<myFactory1.data.length;i++)
        {
            returnedArray.data[i].departmentName = newProp();
            returnedArray.data[i].employee = newPropEmp();
            returnedArray.data[i].task = newPropTask();
        }
        return returnedArray;
    }])
.controller('View4Ctrl', [ '$scope','View4Factory', function($scope,View4Factory) {
    $scope.infos = View4Factory;
}]);